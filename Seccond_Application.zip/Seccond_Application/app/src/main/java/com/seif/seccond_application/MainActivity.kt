package com.seif.seccond_application

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toDrawable

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        supportActionBar?.apply {
            displayOptions = androidx.appcompat.app.ActionBar.DISPLAY_SHOW_CUSTOM
            setCustomView(R.layout.centered_title)
        }
        supportActionBar?.setBackgroundDrawable(
            ContextCompat.getColor(this, R.color.Red).toDrawable()
        )

        val logoImage: ImageView = findViewById(R.id.google_logo)
        val fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in)
        fadeIn.duration = 2000
        logoImage.startAnimation(fadeIn)

        val linkedinText: TextView = findViewById(R.id.linkedin_text)
        linkedinText.setOnClickListener {
            val url = "https://linkedin.com/in/seifemad0"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }
        val whatsappText: TextView = findViewById(R.id.whatsapp_text)
        whatsappText.setOnClickListener {
            val phoneNumber = "+201029079781"
            val url = "https://wa.me/${phoneNumber.replace("+", "")}"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }


    }
}